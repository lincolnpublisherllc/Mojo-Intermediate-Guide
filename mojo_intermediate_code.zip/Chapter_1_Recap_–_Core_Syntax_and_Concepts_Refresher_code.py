python
age = 25  # Integer
name = "Alice"  # String